# spring-boot-user-registration

**Turkce Medium:** https://medium.com/@kamer.dev/spring-boot-uygulamas%C4%B1nda-%C3%BCye-kayd%C4%B1-ve-giri%C5%9Fi-3dac83837c9d

**English Medium:** https://medium.com/@kamer.dev/spring-boot-user-registration-and-login-43a33ea19745


**Turkce (Kendi Blogum):** https://kamerelciyar.com/spring-boot-uygulamasinda-uye-kaydi-ve-girisi/

**English (My Own Blog)** https://kamerelciyar.com/spring-boot-user-registration-and-login/

[EN] It's a project for those who want to add user registration and login for a Spring Boot Application. I ommited exception-handling parts so it's not suitable for real usages. You should add exception handling. If you want to try you should change Spring Mail config in application.yml file. Any questions or suggestions, you can reach me on kamer[at]kamerelciyar.com.

[TR] Bu proje, Spring Boot uygulamanıza üye kaydı ve girişi eklemek için kullanabileceğiniz bir projedir. Klonlayıp kullanmak için application.yml dosyasındaki Spring Mail ayarlarını değiştirmeniz gerekmektedir.
