package com.kamer.springbootuserregistration.entity;

/**
 * Created on September, 2019
 *
 * @author kamer
 */
enum UserRole {

	ADMIN, USER
}
