package com.kamer.springbootuserregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUserRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUserRegistrationApplication.class, args);
	}

}

